#! /bin/bash

WORKING_DIR=$(dirname "$0")
cd -P "$WORKING_DIR"/.. > /dev/null

CL_PATH=$(find ./tools -name '*.jar' | tr "\n" :)
echo "CLASSPATH=$CL_PATH"

# 使用agent的classpath下的pinpoint-agent-ewt-2.2.2-SNAPSHOT/pinpoint-root.config【使用绝对路径】, 并变更rpc的collector的ip地址即可
java -cp $CL_PATH com.navercorp.pinpoint.tools.NetworkAvailabilityChecker ./pinpoint-root.config
